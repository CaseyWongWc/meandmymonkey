# main.py
import json

def speak():
    with open("memory.json", "r") as f:
        mem = json.load(f)
    name = mem.get("name", "Agent Froggy")
    print(f"Hello, I am {name}.")

if __name__ == "__main__":
    speak()
