# Agent Froggy

## Role
- Greet the user
- Retrieve and display memory

## Behavior
- Reads `memory.json` to determine its identity
- Prints a greeting message to the console
